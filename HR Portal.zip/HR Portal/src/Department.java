import java.util.ArrayList;

public class Department {
    String name;
    public Department(String name){
        this.name = name;
    }
    public String getName(){
        return name;
    }
}